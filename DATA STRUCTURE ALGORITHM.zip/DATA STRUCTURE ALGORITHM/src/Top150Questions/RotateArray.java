package Top150Questions;

public class RotateArray {
    public static void rotate(int[] nums, int k){
        int n = nums.length-1;
        int[] ans =new int[nums.length];
        for (int i = 0; i <= nums.length -1; i++) {
            ans[i] = nums[n];
        }

        System.out.print(ans);
    }

    public static void main(String[] args) {
        int[] nums = {1,2,3,4,5,6,7};
        int k = 3;

        rotate(nums,k);

    }
}
