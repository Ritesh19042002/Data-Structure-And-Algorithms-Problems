package Methods;

public class Standard {
    public static void main(String[] args) {
        System.out.println(Math.sqrt(24));

        System.out.println(Math.floor(2.4));
        System.out.println(Math.floor(2.6));

        System.out.println(Math.ceil(2.4));
        System.out.println(Math.ceil(2.6));
    }
}
