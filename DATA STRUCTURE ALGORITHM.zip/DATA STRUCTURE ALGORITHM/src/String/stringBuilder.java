package String;
import java.util.*;
public class stringBuilder {
    public static void main(String[] args) {
        StringBuilder str = new StringBuilder("hello");
        System.out.println(str);
    }
}
