package String;

import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class String1 {
        public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);
            int i=1;
            while (sc.hasNext()) {
                String s=sc.nextLine();
                System.out.println(i + " " + s);
                i++;
            }
            }
        }

