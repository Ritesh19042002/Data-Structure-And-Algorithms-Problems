package Arrays;

public class FirstArray {
    public static void main(String[] args) {

        String[] arr = {"P","Q","R"};
        args = arr;
        for (String s:args) {
            System.out.println(s);
        }
    }
}

