//abstract class DemoNoMain extends javafx.application.Application
//{
//    static      //static block
//    {
//        System.out.println("Java");
//        System.exit(0);
//    }
//}