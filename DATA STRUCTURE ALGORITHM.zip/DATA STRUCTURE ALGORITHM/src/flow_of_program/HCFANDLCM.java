package flow_of_program;
// Take 2 numbers as inputs and find their HCF and LCM.
import java.util.*;
public class HCFANDLCM {
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter first number :");
        int num1 = sc.nextInt();
        System.out.println("Enter Second number :");
        int num2 = sc.nextInt();
    }
}
